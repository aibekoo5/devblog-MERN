Object.defineProperty(exports, '__esModule', { value: true });

var React = require('react');
var shared = require('@uploadthing/shared');
var client = require('uploadthing/client');

function _interopDefault (e) { return e && e.__esModule ? e : { default: e }; }

var React__default = /*#__PURE__*/_interopDefault(React);

var peerDependencies = {
	next: "*",
	react: "^17.0.2 || ^18.0.0",
	uploadthing: "^7.2.0"
};

// Ripped from https://github.com/scottrippey/react-use-event-hook
const noop = ()=>void 0;
/**
 * Suppress the warning when using useLayoutEffect with SSR. (https://reactjs.org/link/uselayouteffect-ssr)
 * Make use of useInsertionEffect if available.
 */ const useInsertionEffect = typeof window !== "undefined" ? React__default.default.useInsertionEffect || React__default.default.useLayoutEffect : noop;
/**
 * Similar to useCallback, with a few subtle differences:
 * - The returned function is a stable reference, and will always be the same between renders
 * - No dependency lists required
 * - Properties or state accessed within the callback will always be "current"
 */ function useEvent(callback) {
    // Keep track of the latest callback:
    const latestRef = React__default.default.useRef(// eslint-disable-next-line @typescript-eslint/no-unsafe-argument
    useEvent_shouldNotBeInvokedBeforeMount);
    useInsertionEffect(()=>{
        latestRef.current = callback;
    }, [
        callback
    ]);
    // Create a stable callback that always calls the latest callback:
    // using useRef instead of useCallback avoids creating and empty array on every render
    const stableRef = React__default.default.useRef();
    if (!stableRef.current) {
        stableRef.current = function() {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-return, prefer-rest-params, @typescript-eslint/no-unsafe-argument
            return latestRef.current.apply(this, arguments);
        };
    }
    return stableRef.current;
}
/**
 * Render methods should be pure, especially when concurrency is used,
 * so we will throw this error if the callback is called while rendering.
 */ function useEvent_shouldNotBeInvokedBeforeMount() {
    throw new Error("INVALID_USEEVENT_INVOCATION: the callback from useEvent cannot be invoked before the component has mounted.");
}

// Ripped from https://usehooks-ts.com/react-hook/use-fetch
function useFetch(url, options) {
    const cache = React.useRef({});
    // Used to prevent state update if the component is unmounted
    const cancelRequest = React.useRef(false);
    const initialState = {
        error: undefined,
        data: undefined
    };
    // Keep state logic separated
    const fetchReducer = (state, action)=>{
        switch(action.type){
            case "loading":
                return {
                    ...initialState
                };
            case "fetched":
                return {
                    ...initialState,
                    data: action.payload
                };
            case "error":
                return {
                    ...initialState,
                    error: action.payload
                };
            default:
                return state;
        }
    };
    const [state, dispatch] = React.useReducer(fetchReducer, initialState);
    React.useEffect(()=>{
        // Do nothing if the url is not given
        if (!url) return;
        cancelRequest.current = false;
        const fetchData = async ()=>{
            dispatch({
                type: "loading"
            });
            // If a cache exists for this url, return it
            if (cache.current[url]) {
                dispatch({
                    type: "fetched",
                    payload: cache.current[url]
                });
                return;
            }
            try {
                const response = await fetch(url, options);
                if (!response.ok) {
                    throw new Error(response.statusText);
                }
                const dataOrError = await shared.safeParseJSON(response);
                if (dataOrError instanceof Error) {
                    throw dataOrError;
                }
                cache.current[url] = dataOrError;
                if (cancelRequest.current) return;
                dispatch({
                    type: "fetched",
                    payload: dataOrError
                });
            } catch (error) {
                if (cancelRequest.current) return;
                dispatch({
                    type: "error",
                    payload: error
                });
            }
        };
        void fetchData();
        // Use the cleanup function for avoiding a possibly...
        // ...state update after the component was unmounted
        return ()=>{
            cancelRequest.current = true;
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        url
    ]);
    return state;
}

const useRouteConfig = (url, endpoint)=>{
    const maybeServerData = globalThis.__UPLOADTHING;
    const { data } = useFetch(// Don't fetch if we already have the data
    maybeServerData ? undefined : url.href);
    return (maybeServerData ?? data)?.find((x)=>x.slug === endpoint)?.config;
};
/**
 * @internal - This is an internal function. Use `generateReactHelpers` instead.
 * The actual hook we export for public usage is generated from `generateReactHelpers`
 * which has the URL and FileRouter generic pre-bound.
 */ function __useUploadThingInternal(url, endpoint, opts) {
    const { uploadFiles, routeRegistry } = client.genUploader({
        url,
        package: "@uploadthing/react"
    });
    const [isUploading, setUploading] = React.useState(false);
    const uploadProgress = React.useRef(0);
    const fileProgress = React.useRef(new Map());
    const startUpload = useEvent(async (...args)=>{
        const files = await opts?.onBeforeUploadBegin?.(args[0]) ?? args[0];
        const input = args[1];
        setUploading(true);
        files.forEach((f)=>fileProgress.current.set(f, 0));
        opts?.onUploadProgress?.(0);
        try {
            const res = await uploadFiles(endpoint, {
                signal: opts?.signal,
                headers: opts?.headers,
                files,
                onUploadProgress: (progress)=>{
                    if (!opts?.onUploadProgress) return;
                    fileProgress.current.set(progress.file, progress.progress);
                    let sum = 0;
                    fileProgress.current.forEach((p)=>{
                        sum += p;
                    });
                    const averageProgress = Math.floor(sum / fileProgress.current.size / 10) * 10;
                    if (averageProgress !== uploadProgress.current) {
                        opts?.onUploadProgress?.(averageProgress);
                        uploadProgress.current = averageProgress;
                    }
                },
                onUploadBegin ({ file }) {
                    if (!opts?.onUploadBegin) return;
                    opts.onUploadBegin(file);
                },
                // @ts-expect-error - input may not be defined on the type
                input
            });
            await opts?.onClientUploadComplete?.(res);
            return res;
        } catch (e) {
            /**
       * This is the only way to introduce this as a non-breaking change
       * TODO: Consider refactoring API in the next major version
       */ if (e instanceof shared.UploadAbortedError) throw e;
            let error;
            if (e instanceof shared.UploadThingError) {
                error = e;
            } else {
                error = shared.INTERNAL_DO_NOT_USE__fatalClientError(e);
                console.error("Something went wrong. Please contact UploadThing and provide the following cause:", error.cause instanceof Error ? error.cause.toString() : error.cause);
            }
            await opts?.onUploadError?.(error);
        } finally{
            setUploading(false);
            fileProgress.current = new Map();
            uploadProgress.current = 0;
        }
    });
    const _endpoint = shared.unwrap(endpoint, routeRegistry);
    const routeConfig = useRouteConfig(url, _endpoint);
    return {
        startUpload,
        isUploading,
        routeConfig
    };
}
const generateReactHelpers = (initOpts)=>{
    shared.warnIfInvalidPeerDependency("@uploadthing/react", peerDependencies.uploadthing, client.version);
    const url = shared.resolveMaybeUrlArg(initOpts?.url);
    const clientHelpers = client.genUploader({
        url,
        package: "@uploadthing/react"
    });
    function useUploadThing(endpoint, opts) {
        return __useUploadThingInternal(url, endpoint, opts);
    }
    function getRouteConfig(slug) {
        const maybeServerData = globalThis.__UPLOADTHING;
        const endpoint = shared.unwrap(slug, clientHelpers.routeRegistry);
        const config = maybeServerData?.find((x)=>x.slug === endpoint)?.config;
        if (!config) {
            throw new Error(`No config found for endpoint "${endpoint.toString()}". Please make sure to use the NextSSRPlugin in your Next.js app.`);
        }
        return config;
    }
    return {
        useUploadThing,
        ...clientHelpers,
        /**
     * Get the config for a given endpoint outside of React context.
     * @remarks Can only be used if the NextSSRPlugin is used in the app.
     */ getRouteConfig
    };
};

exports.__useUploadThingInternal = __useUploadThingInternal;
exports.generateReactHelpers = generateReactHelpers;
