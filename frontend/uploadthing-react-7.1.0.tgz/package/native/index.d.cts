import * as uploadthing_types from 'uploadthing/types';
import { FileRouter, inferEndpointOutput, ClientUploadedFileData, inferErrorShape, EndpointArg, inferEndpointInput } from 'uploadthing/types';
import { ErrorMessage, MaybePromise, UploadThingError, ExpandedRouteConfig } from '@uploadthing/shared';

interface GenerateTypedHelpersOptions {
    /**
     * URL to the UploadThing API endpoint
     * @example "/api/uploadthing"
     * @example "https://www.example.com/api/uploadthing"
     *
     * If relative, host will be inferred from either the `VERCEL_URL` environment variable or `window.location.origin`
     *
     * @default (VERCEL_URL ?? window.location.origin) + "/api/uploadthing"
     */
    url?: string | URL;
}
type UseUploadthingProps<TRouter extends FileRouter, TEndpoint extends keyof TRouter, TServerOutput = inferEndpointOutput<TRouter[TEndpoint]>> = {
    /**
     * Called when the upload is submitted and the server is about to be queried for presigned URLs
     * Can be used to modify the files before they are uploaded, e.g. renaming them
     */
    onBeforeUploadBegin?: ((files: File[]) => Promise<File[]> | File[]) | undefined;
    /**
     * Called when presigned URLs have been retrieved and the file upload is about to begin
     */
    onUploadBegin?: ((fileName: string) => void) | undefined;
    /**
     * Called continuously as the file is uploaded to the storage provider
     */
    onUploadProgress?: ((p: number) => void) | undefined;
    /**
     * This option has been moved to your serverside route config.
     * Please opt-in by setting `awaitServerData: false` in your route
     * config instead.
     * ### Example
     * ```ts
     * f(
     *   { image: { maxFileSize: "1MB" } },
     *   { awaitServerData: false }
     * ).middleware(...)
     * ```
     * @deprecated
     * @see https://docs.uploadthing.com/api-reference/server#route-options
     */
    skipPolling?: ErrorMessage<"This option has been moved to your serverside route config. Please use `awaitServerData` in your route config instead.">;
    /**
     * Called when the file uploads are completed
     * @remarks If `RouteOptions.awaitServerData` is `true`, this will be
     * called after the serverside `onUploadComplete` callback has finished
     */
    onClientUploadComplete?: ((res: ClientUploadedFileData<TServerOutput>[]) => MaybePromise<void>) | undefined;
    /**
     * Called if the upload fails
     */
    onUploadError?: ((e: UploadThingError<inferErrorShape<TRouter>>) => MaybePromise<void>) | undefined;
    /**
     * Set custom headers that'll get sent with requests
     * to your server
     */
    headers?: HeadersInit | (() => MaybePromise<HeadersInit>) | undefined;
    /**
     * An AbortSignal to cancel the upload
     * Calling `abort()` on the parent AbortController will cause the
     * upload to throw an `UploadAbortedError`. In a future version
     * the function will not throw in favor of an `onUploadAborted` callback.
     */
    signal?: AbortSignal | undefined;
};

/**
 * @internal - This is an internal function. Use `generateReactHelpers` instead.
 * The actual hook we export for public usage is generated from `generateReactHelpers`
 * which has the URL and FileRouter generic pre-bound.
 */
declare function __useUploadThingInternal<TRouter extends FileRouter, TEndpoint extends keyof TRouter>(url: URL, endpoint: EndpointArg<TRouter, TEndpoint>, opts?: UseUploadthingProps<TRouter, TEndpoint>): {
    readonly startUpload: (...args: undefined extends inferEndpointInput<TRouter[TEndpoint]> ? [files: File[], input?: undefined] : [files: File[], input: inferEndpointInput<TRouter[TEndpoint]>]) => Promise<uploadthing_types.ClientUploadedFileData<uploadthing_types.inferEndpointOutput<TRouter[TEndpoint]>>[] | undefined>;
    readonly isUploading: boolean;
    readonly routeConfig: ExpandedRouteConfig | undefined;
};
declare const generateReactHelpers: <TRouter extends FileRouter>(initOpts?: GenerateTypedHelpersOptions) => {
    /**
     * Get the config for a given endpoint outside of React context.
     * @remarks Can only be used if the NextSSRPlugin is used in the app.
     */
    readonly getRouteConfig: (slug: EndpointArg<TRouter, keyof TRouter>) => ExpandedRouteConfig;
    readonly uploadFiles: <TEndpoint extends keyof TRouter>(slug: EndpointArg<TRouter, TEndpoint>, opts: Omit<uploadthing_types.UploadFilesOptions<TRouter, TEndpoint>, keyof uploadthing_types.GenerateUploaderOptions>) => Promise<uploadthing_types.ClientUploadedFileData<uploadthing_types.inferEndpointOutput<TRouter[TEndpoint]>>[]>;
    readonly createUpload: <TEndpoint extends keyof TRouter, TServerOutput = uploadthing_types.inferEndpointOutput<TRouter[TEndpoint]>>(slug: EndpointArg<TRouter, TEndpoint>, opts: Omit<uploadthing_types.CreateUploadOptions<TRouter, TEndpoint>, keyof uploadthing_types.GenerateUploaderOptions>) => Promise<{
        pauseUpload: (file?: File) => void;
        resumeUpload: (file?: File) => void;
        done: <T extends File | void = void>(file?: T | undefined) => Promise<T extends File ? uploadthing_types.ClientUploadedFileData<TServerOutput> : uploadthing_types.ClientUploadedFileData<TServerOutput>[]>;
    }>;
    readonly routeRegistry: uploadthing_types.RouteRegistry<TRouter>;
    readonly useUploadThing: <TEndpoint extends keyof TRouter>(endpoint: EndpointArg<TRouter, TEndpoint>, opts?: UseUploadthingProps<TRouter, TEndpoint>) => {
        readonly startUpload: (...args: undefined extends inferEndpointInput<TRouter[TEndpoint]> ? [files: File[], input?: inferEndpointInput<TRouter[TEndpoint]> & undefined] : [files: File[], input: inferEndpointInput<TRouter[TEndpoint]>]) => Promise<uploadthing_types.ClientUploadedFileData<uploadthing_types.inferEndpointOutput<TRouter[TEndpoint]>>[] | undefined>;
        readonly isUploading: boolean;
        readonly routeConfig: ExpandedRouteConfig | undefined;
    };
};

export { __useUploadThingInternal, generateReactHelpers };
