import { EndpointMetadata } from '@uploadthing/shared';

declare function NextSSRPlugin(props: {
    routerConfig: EndpointMetadata;
}): null;

export { NextSSRPlugin };
